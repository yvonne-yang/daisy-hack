from __future__ import print_function
from abc import ABCMeta, abstractmethod
import random
import numpy as np
from typing import List, Dict, Optional, Tuple
import copy
import sys
# from itertools import product
# from tqdm import tqdm
# import numpy as np

from site_location import SiteLocationPlayer, Store, SiteLocationMap, euclidian_distances, attractiveness_allocation, \
    SiteLocationGame




class BaseAgent:
    """Implements the agent for an RL-Glue environment.
    Note:
        agent_init, agent_start, agent_step, agent_end, agent_cleanup, and
        agent_message are required methods.
    """

    __metaclass__ = ABCMeta

    def __init__(self):
        pass

    @abstractmethod
    def agent_init(self, agent_info= {}):
        """Setup for the agent called when the experiment first starts."""

    @abstractmethod
    def agent_start(self, observation):
        """The first method called when the experiment starts, called after
        the environment starts.
        Args:
            observation (Numpy array): the state observation from the environment's env_start function.
        Returns:
            The first action the agent takes.
        """

    @abstractmethod
    def agent_step(self, reward, observation):
        """A step taken by the agent.
        Args:
            reward (float): the reward received for taking the last action taken
            observation (Numpy array): the state observation from the
                environment's step based, where the agent ended up after the
                last step
        Returns:
            The action the agent is taking.
        """

    @abstractmethod
    def agent_end(self, reward):
        """Run when the agent terminates.
        Args:
            reward (float): the reward the agent received for entering the terminal state.
        """

    @abstractmethod
    def agent_reset(self):
        """Cleanup done after the agent ends."""

    @abstractmethod
    def agent_message(self, message):
        """A function used to pass information from the agent to the experiment.
        Args:
            message: The message passed to the agent.
        Returns:
            The response (or answer) to the message.
        """

class SmartAgent(BaseAgent):

    def agent_init(self, agent_info={}, default_conf=None):
        '''
            Think about using net profit as a second classifier for state,
            so that our algorithm could act better based on how much money it's ahead of/behind others
        '''
        self.randGenerator = np.random.RandomState()
        self.epsilon = agent_info["epsilon"] ## variable for epsilon greedy choice
        self.rounds = agent_info["num_rounds"] ## number of rounds, for identifying this episode
        self.states = np.arange(self.rounds) ## COULD exist a 2nd index in tuple: The profit classifier (if we make max profit or not)
        self.visited_sa_pair = [] ## State action pair that we have visited each episode
        self.discount_factor = agent_info["discount"]
        self.config = default_conf
        self.num_actions = 3 # copycat and maximize(1. allocation 2. distance away from stores)
        ## attractiveness allocation
        # self.size_counter = np.zeroes((self.rounds, self.actions))
        self.q = agent_info["q_values"]
        
    def flatten_state(self, tup):
        '''
            Helper Function
        '''
        return tup[0] * 2 + tup[1]

    def agent_start(self, state):
        action = None
        if self.randGenerator.rand() < self.epsilon:
            '''
                Explore actions
            '''
            action = self.randGenerator.randint(self.num_actions)
        else:
            action = self.argmax(self.q[state, :])

        self.visited_sa_pair.append((state, action))
        return action

    def agent_step(self, state):
        '''
            Like above, we simply choose the action here.
        '''
        action = None
        if self.randGenerator.rand() < self.epsilon:
            '''
                Explore actions
            '''
            action = self.randGenerator.randint(self.num_actions)
        else:
            action = self.argmax(self.q[state, :])

        self.visited_sa_pair.append((state, action))
        return action

    def agent_end(self, reward):
        '''
            Apply the reward only at the end of a game.
            We can also consider applying reward at every step, 
            but that would require state to become a tuple of (a,b)
            where a is from 0 to self.episodes while b states 
            your net-profit (which can be positive or negative) 
        '''
        for i, pair in enumerate(self.visited_sa_pair):
            state, action = pair
            if action == 0 and i < 3:
                pass
            
            self.q[state, action] += reward
        
        if reward == -1:
            self.discount_factor = self.discount_factor * 0.95

    def agent_reset(self, discount_factor=None, epsilon=None):
        '''
            Use this chance to reassign values.
            Reassign discount factor
        '''        
        print(self.q)
        self.visited_sa_pair = []
        
    def agent_message(self, message):
        raise NotImplementedError

    def argmax(self, q_values):
        """argmax with random tie-breaking
        Args:
            q_values (Numpy array): the array of action-values
        Returns:
            action (int): an action with the highest value
        """
        top = float("-inf")
        ties = []

        for i in range(len(q_values)):
            if q_values[i] > top:
                top = q_values[i]
                ties = []

            if q_values[i] == top:
                ties.append(i)

        return self.randGenerator.choice(ties)

SCORES = []
class DummyGame(SiteLocationGame):
    def __init__(self, config: Dict, player_classes: List[type], 
                 allocation_func):
        self.scores = [{}]
        
class NothingPlayer(SiteLocationPlayer):
    def place_stores(self, slmap: SiteLocationMap, 
                     store_locations: Dict[int, List[Store]],
                     current_funds: float):
        self.stores_to_place = []
        pass


class OverthinkingPlayer(SiteLocationPlayer):
    '''
        Named to reflect how much I overthought about this
    '''
    def __init__(self, player_id, config):
        SiteLocationPlayer.__init__(self, player_id, config)
        self.roundNumber = 0
        self.encouragedPrice = int(config["store_config"]["large"]["capital_cost"] * 1.25)
        agent_info = {"epsilon" : 0.1, "num_rounds" : DEFAULT_CONFIGURATION["n_rounds"],
        "discount" : 0.9, "q_values" : q_values, "default_conf" : DEFAULT_CONFIGURATION}
        self.agent = SmartAgent()
        self.agent.agent_init(agent_info)
        


    def place_stores(self, slmap: SiteLocationMap, 
    store_locations: Dict[int, List[Store]], current_funds: float):
        self.roundNumber = self.roundNumber % self.config["n_rounds"]
        self.agent.q = np.array([[10,0,1], [10,0,2], [9,0,10], [8,0,10], [7,0,10], [6,0,10], [10,10,10], [6,6,3], [5,7,2], [4,7,3]])
        action = agent.agent_step(self.roundNumber) ## Default Starting State. You're on Round 0,
        store_conf = list(self.config["store_config"].keys())
        store_type = ""
        if action == 0:    
            self.most_dense(slmap, store_locations, current_funds)
        elif action == 1:
            self.copy_cat(slmap, store_locations, current_funds)
        elif action == 2:
            self.most_dense(slmap, store_locations, current_funds, two_buys=True)
        
        self.roundNumber += 1
        self.encouragedPrice *= agent.discount_factor
        ## and you aint richer than anyone

    def moving_density_calculator(self, slmap: SiteLocationMap,
    store_locations: Dict[int, List[Store]], current_funds: float, SM_GRID=(60,60)):
        '''
            Description: Moving_UnagiDonCity_Calckers
            Move in 60x60 grid and sum of every possible 60x60 grid (The sum is stored in product array of 240x240)
            @Returns:  The product array of 240x240
        '''
        noise = slmap.population_distribution
        area = np.zeros(shape=(slmap.size[0] - SM_GRID[0], slmap.size[1] - SM_GRID[1])) ## all the area values we will store
        for i in range(slmap.size[0] - SM_GRID[0]):
            for j in range(slmap.size[1] - SM_GRID[1]):
                area[i, j] = np.sum(noise[i:i+SM_GRID[0], j:j+SM_GRID[1]]) ## element-wise

        return area
    
    def most_dense(self, slmap: SiteLocationMap, 
                     store_locations: Dict[int, List[Store]],
                     current_funds: float, two_buys=False):
        store_conf = self.config['store_config']
        '''
            Select the most dense grids in the world, based on a subgrid.
            The subgrid gets smaller and smaller over time, as there becomes less space available
            and finding optimal points of profit becomes harder.
        '''

        # Configurable minimum distance away to place store
        min_dist = 141 
        # Check if it can buy any store at all
        if current_funds < store_conf['small']['capital_cost']:
            self.stores_to_place = []
            return
        
        
        if two_buys:
            if self.encouragedPrice >= store_conf["large"]["capital_cost"]*2 and current_funds >= store_conf["large"]["capital_cost"]*2:
                store_type = ['large', 'large']
            elif self.encouragedPrice >= store_conf["large"]["capital_cost"]*2 and current_funds >= store_conf["medium"]["capital_cost"]*2:
                store_type = ['large', 'medium']
            elif self.encouragedPrice >= store_conf["large"]["capital_cost"]*2 and current_funds >= store_conf["small"]["capital_cost"]*2:
                store_type = ['large', 'small'] 
            elif self.encouragedPrice >= store_conf["medium"]["capital_cost"]*2 and current_funds >= store_conf["medium"]["capital_cost"]*2:
                store_type = ['medium', 'medium']
            elif self.encouragedPrice >= store_conf["medium"]["capital_cost"]*2 and current_funds >= store_conf["small"]["capital_cost"]*2:
                store_type = ['medium', 'small'] 
            elif self.encouragedPrice >= store_conf["small"]["capital_cost"]*2 and current_funds >= store_conf["small"]["capital_cost"]*2:
                store_type = ['small', 'small'] 
            else:
                two_buys = False
        
        ## On first round, choose one small store and one medium store
        if current_funds >= store_conf['small']['capital_cost'] + store_conf["medium"]["capital_cost"] and self.roundNumber == 0:
            store_type = ['small', "medium"]
        # Choose largest store type possible
        elif self.encouragedPrice >= store_conf["large"]["capital_cost"] and current_funds >= store_conf["large"]["capital_cost"]:
            store_type = 'large'
        elif self.encouragedPrice >= store_conf["medium"]["capital_cost"] and current_funds >= store_conf["medium"]["capital_cost"]:
            store_type = 'medium'
        elif self.encouragedPrice >= store_conf["small"]["capital_cost"] and current_funds >= store_conf["small"]["capital_cost"]:
            store_type = 'small'
            if self.roundNumber <= 6:
                return
        else:
            self.stores_to_place = []
            return
    

        # Find highest population location that's at least 100m away from your location. Else, do nothing.
        all_stores_pos = []
        for player_store in store_locations[self.player_id]:
                all_stores_pos.append(player_store.pos)
        counter = 0
        SM_GRID = (int(90 / max(self.roundNumber, 1)), int(90 / max(self.roundNumber, 1))) ## decreases with roundNumber
        area = self.moving_density_calculator(slmap, store_locations, current_funds, SM_GRID)
        area_indices = tuple(map(tuple, np.dstack(np.unravel_index(np.argsort(area.ravel()), area.shape))[0][::-1]))
        for max_pos in area_indices:
            too_close = False
            actual_pos = (max_pos[0] + int(SM_GRID[0]/2) - 1, max_pos[1] + int(SM_GRID[1]/2) - 1)
            for pos in all_stores_pos:
                dist = np.sqrt(np.square(actual_pos[0]-pos[0]) + np.square(actual_pos[1]-pos[1]))
                if dist < min_dist:
                    too_close = True
            if not too_close:
                if isinstance(store_type, list):
                    self.stores_to_place.append(Store(actual_pos, store_type[counter]))
                    all_stores_pos.append(actual_pos)
                    if len(self.stores_to_place) == 2:
                        return
                    counter += 1
                else: 
                    self.stores_to_place.append(Store(actual_pos, store_type))
                    return

    def do_nothing(self):
        pass

    def copy_cat(self, slmap: SiteLocationMap, 
                     store_locations: Dict[int, List[Store]],
                     current_funds: float):
        '''
            Copy the opponent who has the most number of stores among your opponents.
        '''
        store_conf = self.config['store_config']
        store_type = None
        pickOne = random.choice([True, False])
        if self.encouragedPrice >= store_conf["large"]["capital_cost"] and current_funds >= store_conf["large"]["capital_cost"]:
            store_type = 'large'
            if self.roundNumber >= 9:
                return
        elif self.encouragedPrice >= store_conf["medium"]["capital_cost"] and current_funds >= store_conf["medium"]["capital_cost"]:
            store_type = 'medium'
        elif self.encouragedPrice >= store_conf["small"]["capital_cost"] and current_funds >= store_conf["small"]["capital_cost"]:
            store_type = 'small'
        else:
            self.stores_to_place = []
            return

        self_stores_pos = []
        for store in store_locations[self.player_id]:
            self_stores_pos.append(store.pos)

        opp_store_locations = {k:v for (k,v) in store_locations.items() if k != self.player_id}
        opp_all_stores = []
        
        ## get longest element in dictionary
        longestIndex = 0
        longestValue = 0
        for player, player_stores in opp_store_locations.items():
            if len(player_stores) >= longestValue:
                longestValue = len(player_stores)
                longestIndex = player
        
        for player_store in opp_store_locations[longestIndex]:
            opp_all_stores.append(player_store)
        
        if not opp_all_stores:
            self.stores_to_place =  []
            return
        else:
            if pickOne:
                self.stores_to_place = [Store(random.choice(opp_all_stores).pos, store_type)]
            else:
                first_item = random.choice(opp_all_stores)
                opp_all_stores.pop(opp_all_stores.index(first_item))
                second_item = random.choice(opp_all_stores)
                ## Only pick the possible choice
                if store_conf[first_item.store_type]["capital_cost"] + store_conf[second_item.store_type]["capital_cost"] <= self.encouragedPrice:
                    self.stores_to_place = [first_item, second_item]    
                elif store_conf[first_item.store_type]["capital_cost"] <= self.encouragedPrice:
                    self.stores_to_place = [first_item]
                elif store_conf[second_item.store_type]["capital_cost"] <= self.encouragedPrice:
                    self.stores_to_place = [second_item]
                
                return
        
    def valid_action(self, current_funds, config, action):
        pass


    def grid_search(self, test_params=[0.001, 0.005, 0.01, 0.015, 0.03, 0.1]):
        pass